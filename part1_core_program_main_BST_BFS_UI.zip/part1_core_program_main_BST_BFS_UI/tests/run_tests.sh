#!/bin/bash
set -e
cd "$(dirname "$0")/.."
make
echo "Created executable. Running a quick smoke test..."
# load sample fields then list them
./smart_farming_system <<EOF
11
fields_sample.txt
3
0
EOF
echo "Smoke test finished."

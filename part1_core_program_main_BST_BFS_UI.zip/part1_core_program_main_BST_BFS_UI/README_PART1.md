# Part 1 - Core Program (main), BST, Pipeline BFS and Web UI

This is the "Core Program" work item from the team report: the main logic that integrates the BST, Max-Heap, Queue and planner modules, the interactive CLI menu, and testing with sample inputs. It also includes the Field BST, the Pipeline BFS and the web UI, because the main program is what connects them.

## Your files
| File | What it is |
|---|---|
| `main.cpp` | menu loop, input handling, calls into every module |
| `field_bst.h/.cpp` | Binary Search Tree of fields, save/load, `collect_fields_into_array` |
| `pipeline_bfs.h/.cpp` | graph (adjacency list) + BFS shortest path |
| `Makefile`, `tests/` | build, your tests, smoke test |
| `server.py`, `ui/`, `start_ui.*` | web UI that runs the compiled program |
| `fields_sample.txt`, `pipeline_network.txt` | demo data |
| `partner_files/` | Part 2's modules (read-only copy so you can run the whole program) |

## Menu options you own
All 12 menu choices live in `main.cpp`. The calls you make:

| Option | What main.cpp does | Module |
|---|---|---|
| 1 / 2 / 3 | add-update, remove, list fields | your BST |
| 4 / 5 | enqueue (after checking the field exists) / dequeue | Part 2 queue |
| 6 / 7 | build heap from all fields by dryness / extract the driest | Part 2 heap |
| 8 | predict yield of one field | Part 2 prediction |
| 9 | multi-day greedy irrigation plan | Part 2 planner |
| 10 / 11 | save / load fields file | your BST |
| 12 | load pipeline edges, BFS shortest path | your BFS |

## Run
```bash
make              # builds the full program (uses partner_files/)
./smart_farming_system
make test         # BST and BFS tests, expected: both "all tests passed"
bash tests/run_tests.sh   # quick smoke test of the menu
```
Web UI: `make`, then `python server.py`, then open `ui/index.html`.

## What you must understand and be able to explain
- **BST** (`insertField` / `searchField` / `removeField`, O(h)): left is smaller, right is bigger; delete has 3 cases, the two-children case uses the smallest node of the right subtree. In-order traversal prints sorted by ID. `bst_free` frees nodes in post-order.
- **Why `collect_fields_into_array`** exists: it copies the tree in-order into an array so the heap (option 6) and the planner (option 9) can work on it. Calling it with `nullptr` only counts the fields.
- **BFS** (O(V + E)): explores pipes level by level with a queue, so the first time it reaches the target is the fewest pipes. The graph is undirected (each edge stored both ways).
- **main.cpp**: how the modules connect, how bad input and end of input are handled without hanging.

## Likely viva questions
1. Why is the BST a good store for fields? What is its worst case? (sorted insert gives a linked list; AVL fixes it)
2. How does main.cpp use the heap and why is the heap built from an array? (heapify is O(n))
3. Why BFS and not DFS for the shortest pipe path? (BFS gives fewest edges in an unweighted graph)
4. What does option 4 check before enqueueing?
5. How does the web UI talk to the C++ program? (`server.py` starts the program and sends it menu input)

## Do not change
The function names and signatures in `TEAM_PLAN.md`; Part 2's modules depend on `Field`, `FieldItem` and `collect_fields_into_array`.

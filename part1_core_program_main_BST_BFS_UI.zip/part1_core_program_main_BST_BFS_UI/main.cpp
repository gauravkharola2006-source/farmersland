#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include "field_bst.h"
#include "irrigation_queue.h"
#include "priority_heap.h"
#include "prediction.h"
#include "dp_planner.h"
#include "pipeline_bfs.h"

using namespace std;

void print_menu() {
    cout << "\n=== Smart Farming System ===\n"
         << "1. Add / Update Field\n"
         << "2. Remove Field\n"
         << "3. List all Fields\n"
         << "4. Enqueue field for irrigation\n"
         << "5. Dequeue next irrigation\n"
         << "6. Build priority heap from fields (by dryness)\n"
         << "7. Extract highest priority field\n"
         << "8. Predict yield for field\n"
         << "9. Plan multi-day irrigation (greedy planner)\n"
         << "10. Save fields to file\n"
         << "11. Load fields from file\n"
         << "12. Pipeline BFS test (load edges and query shortest)\n"
         << "0. Exit" << endl;
}

int main() {
    Field *root = nullptr;
    Queue q;
    Heap h;

    int choice;
    while (true) {
        print_menu();
        cout << "Enter choice: ";
        if (!(cin >> choice)) {
            if (cin.eof()) break;                 // input closed -> exit cleanly
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }
        if (choice == 0) break;

        if (choice == 1) {
            int id, moisture; string crop;
            cout << "Field ID: ";             cin >> id;
            cout << "Moisture (0-100): ";     cin >> moisture;
            cout << "Crop (no spaces): ";     cin >> crop;
            root = insertField(root, id, moisture, crop);
            cout << "Field added/updated." << endl;
        }
        else if (choice == 2) {
            int id;
            cout << "Field ID to remove: "; cin >> id;
            root = removeField(root, id);
            cout << "If existed, field removed." << endl;
        }
        else if (choice == 3) {
            cout << "\nListing fields (in-order):" << endl;
            listFields(root);
        }
        else if (choice == 4) {
            int id;
            cout << "Field ID to enqueue: "; cin >> id;
            Field *f = searchField(root, id);
            if (!f) cout << "Field not found." << endl;
            else if (q.enqueue(id) == 0) cout << "Enqueued." << endl;
            else cout << "Queue full." << endl;
        }
        else if (choice == 5) {
            int id;
            if (q.dequeue(id) == 0) cout << "Dequeued field ID " << id << endl;
            else cout << "Queue empty." << endl;
        }
        else if (choice == 6) {
            int n = collect_fields_into_array(root, nullptr);
            if (n == 0) cout << "No fields to build heap." << endl;
            else {
                vector<FieldItem> arr(n);
                collect_fields_into_array(root, arr.data());
                h.build_from_array(arr.data(), n);
                cout << "Heap built from current fields." << endl;
            }
        }
        else if (choice == 7) {
            FieldItem it;
            if (h.extract_max(it) == 0)
                cout << "Highest priority field: ID " << it.id
                     << " Dryness " << it.dryness << " Crop " << it.crop << endl;
            else cout << "Heap empty." << endl;
        }
        else if (choice == 8) {
            int id;
            cout << "Field ID for prediction: "; cin >> id;
            Field *f = searchField(root, id);
            if (!f) cout << "Field not found." << endl;
            else {
                double yield = predict_yield(f->moisture);
                cout.setf(ios::fixed); cout.precision(2);
                cout << "Predicted yield (relative): " << yield << endl;
                cout.unsetf(ios::fixed);
            }
        }
        else if (choice == 9) {
            int days, perday;
            cout << "Number of days to plan: ";       cin >> days;
            cout << "Max fields to water per day: ";  cin >> perday;
            vector<vector<int>> schedule;
            int got = plan_irrigation(root, days, perday, schedule);
            cout << "Planned for " << got << " days:" << endl;
            for (int d = 0; d < got; d++) {
                cout << "Day " << d + 1 << ": ";
                for (int k = 0; k < perday; k++) {
                    if (schedule[d][k] == -1) break;
                    cout << schedule[d][k] << " ";
                }
                cout << "\n";
            }
        }
        else if (choice == 10) {
            string fname;
            cout << "Filename to save: "; cin >> fname;
            if (save_fields(root, fname) == 0) cout << "Saved to " << fname << endl;
            else cout << "Save failed." << endl;
        }
        else if (choice == 11) {
            string fname;
            cout << "Filename to load: "; cin >> fname;
            Field *newroot = load_fields(fname);
            if (newroot) { bst_free(root); root = newroot; cout << "Loaded." << endl; }
            else cout << "Load failed or file empty." << endl;
        }
        else if (choice == 12) {
            string fname;
            cout << "Edges filename: "; cin >> fname;
            int node_count = 0;
            vector<vector<int>> adj;
            if (load_pipeline_network(fname, node_count, adj) != 0) {
                cout << "Failed to load network." << endl;
                continue;
            }
            int s, t;
            cout << "Source node: ";  cin >> s;
            cout << "Target node: ";  cin >> t;
            int dist = bfs_shortest_distance(node_count, adj, s, t);
            if (dist < 0) cout << "No path or error." << endl;
            else cout << "Shortest path length: " << dist << endl;
        }
        else {
            cout << "Invalid choice." << endl;
        }
    }

    bst_free(root);
    return 0;
}
